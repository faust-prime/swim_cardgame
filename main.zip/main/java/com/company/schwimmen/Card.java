package com.company.schwimmen;

public class Card {
    int rank;       //card rank [7,14] (7 is lowest Card), ..., 11:Jack, ..., 14:Ace
    Character suit;  //suit: heart 'h', spade 's', diamond 'd', clubs 'c'

    public Card(int cardType, char cardSymbol){
        this.rank = cardType;
        this.suit = cardSymbol;
    }

    int getValue() {
        if (this.rank==14) return 11;
        else if (this.rank >=10) return 10;
        return this.rank;
    }
}
