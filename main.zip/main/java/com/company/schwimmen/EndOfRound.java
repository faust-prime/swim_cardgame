package com.company.schwimmen;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;

public class EndOfRound extends Activity {
    ArrayList<Player> punkteAbsteigend =ThirtyOne.spieler;
//    static ArrayList<Player> punkte =new ArrayList<>();
    static float min = 0;
    static float max = 0;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Displayrientation setzen
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);

        //Title-Bar entfernen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);

        setContentView(R.layout.activity_end_of_round);
        setListeners();
        showResults();
    }
    public void setListeners(){
        ImageButton btnMenu = (ImageButton) findViewById(R.id.btnMainMenu);
        if (btnMenu!=null) btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertMessage();
            }
        });

        Button btnNext = (Button) findViewById(R.id.btnContinue);
        if (btnNext!=null) btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nextRound();
            }
        });

    }
    public void showResults(){
        TextView roundCount = (TextView) findViewById(R.id.titleTextRoundCount);
        String message = " #"+ThirtyOne.roundCount;
        if (roundCount!=null) roundCount.setText(message);

        if (!punkteAbsteigend.contains(ThirtyOne.active)) {
            ThirtyOne.spieler.add(ThirtyOne.active);
            punkteAbsteigend = ThirtyOne.spieler;
        }
        for (Player temp: punkteAbsteigend) temp.evaluateHand();
        Collections.sort(punkteAbsteigend, new Player(null));
        min = punkteAbsteigend.get(punkteAbsteigend.size()-1).handValue;  //der letzte Spieler der Liste hat die kleinste Punktzahl
        max = punkteAbsteigend.get(0).handValue;
        //fill ImageButtons and textViews
        //FIXME setText loose a live
        if(punkteAbsteigend.size()>0) {new Hand(punkteAbsteigend.get(0),(ImageView) findViewById(R.id.imageView),  (ImageView) findViewById(R.id.imageView2), (ImageView) findViewById(R.id.imageView3), (TextView) findViewById(R.id.PlayerName1));}
        if(punkteAbsteigend.size()>1) {new Hand(punkteAbsteigend.get(1),(ImageView) findViewById(R.id.imageView4), (ImageView) findViewById(R.id.imageView5), (ImageView) findViewById(R.id.imageView6), (TextView) findViewById(R.id.PlayerName2));}
        if(punkteAbsteigend.size()>2) {new Hand(punkteAbsteigend.get(2),(ImageView) findViewById(R.id.imageView7), (ImageView) findViewById(R.id.imageView8), (ImageView) findViewById(R.id.imageView9), (TextView) findViewById(R.id.PlayerName3));}
//        else                           new Hand(null,(ImageView) findViewById(R.id.imageView7), (ImageView) findViewById(R.id.imageView8), (ImageView) findViewById(R.id.imageView9), (TextView) findViewById(R.id.PlayerName3));
//
        if(punkteAbsteigend.size()>3) {new Hand(punkteAbsteigend.get(3),(ImageView) findViewById(R.id.imageView10),(ImageView) findViewById(R.id.imageView11),(ImageView) findViewById(R.id.imageView12),(TextView) findViewById(R.id.PlayerName4));}
//        else                           new Hand(null,(ImageView) findViewById(R.id.imageView10),(ImageView) findViewById(R.id.imageView11),(ImageView) findViewById(R.id.imageView12),(TextView) findViewById(R.id.PlayerName4));

        if(punkteAbsteigend.size()>4) {new Hand(punkteAbsteigend.get(4),(ImageView) findViewById(R.id.imageView13),(ImageView) findViewById(R.id.imageView14),(ImageView) findViewById(R.id.imageView15),(TextView) findViewById(R.id.PlayerName5));}
//        else                           new Hand(null,                   (ImageView) findViewById(R.id.imageView13),(ImageView) findViewById(R.id.imageView14),(ImageView) findViewById(R.id.imageView15),(TextView) findViewById(R.id.PlayerName5));

        if(punkteAbsteigend.size()>5) {new Hand(punkteAbsteigend.get(5),(ImageView) findViewById(R.id.imageView16),(ImageView) findViewById(R.id.imageView17),(ImageView) findViewById(R.id.imageView18),(TextView) findViewById(R.id.PlayerName6));}
//        else                           new Hand(null,(ImageView) findViewById(R.id.imageView16),(ImageView) findViewById(R.id.imageView17),(ImageView) findViewById(R.id.imageView18),(TextView) findViewById(R.id.PlayerName6));

        if(punkteAbsteigend.size()>6) {new Hand(punkteAbsteigend.get(6),(ImageView) findViewById(R.id.imageView19),(ImageView) findViewById(R.id.imageView20),(ImageView) findViewById(R.id.imageView21),(TextView) findViewById(R.id.PlayerName7));}
//        else                           new Hand(null,(ImageView) findViewById(R.id.imageView19),(ImageView) findViewById(R.id.imageView20),(ImageView) findViewById(R.id.imageView21),(TextView) findViewById(R.id.PlayerName7));

        if(punkteAbsteigend.size()>7) {new Hand(punkteAbsteigend.get(7),(ImageView) findViewById(R.id.imageView22),(ImageView) findViewById(R.id.imageView23),(ImageView) findViewById(R.id.imageView24),(TextView) findViewById(R.id.PlayerName8));}
//        else                           new Hand(null,(ImageView) findViewById(R.id.imageView22),(ImageView) findViewById(R.id.imageView23),(ImageView) findViewById(R.id.imageView24),(TextView) findViewById(R.id.PlayerName8));

        if(punkteAbsteigend.size()>8) {new Hand(punkteAbsteigend.get(8),(ImageView) findViewById(R.id.imageView25),(ImageView) findViewById(R.id.imageView26),(ImageView) findViewById(R.id.imageView27),(TextView) findViewById(R.id.PlayerName9));}
//        else                           new Hand(null,(ImageView) findViewById(R.id.imageView25),(ImageView) findViewById(R.id.imageView26),(ImageView) findViewById(R.id.imageView27),(TextView) findViewById(R.id.PlayerName9));
    }
    public void evaluate(){
        ArrayList<Player> evaluated = new ArrayList<>();
        for (Player temp: punkteAbsteigend){
            ThirtyOne.spieler.get(ThirtyOne.spieler.indexOf(temp)).points.add(temp.adjustedHandValue());
            Log.i("EndOfRound", temp.name+": "+ temp.handValue +"(adjusted: "+temp.adjustedHandValue()+")"+" points, lifes remaining: "+ temp.leben + "♡.");
        }
        if (punkteAbsteigend.size()>0){
            //case of fire: all Players loose a life
            if (max==ThirtyOne.fireValue){
                GameSS.fire(punkteAbsteigend.get(0), ThirtyOne.spieler);
                Log.i("FIRE", " All players exept "+punkteAbsteigend.get(0).name+" losing one life!!!");
            }
            //regular end of game: all Players with minimum Points loose a life
            else {
                try {
                    for (Player temp: ThirtyOne.spieler){
                        if (temp.handValue == min) {
                            temp.looseOneLife();
                            evaluated.add(temp);
                            break;
                        }
                        evaluated.add(temp);

                    }
                    //FIXME 3 players with same points possible
                    for (Player temp: ThirtyOne.spieler){
                        if (temp.handValue == min && !evaluated.contains(temp)) {
                            temp.looseOneLife();
                            evaluated.add(temp);
                            break;
                        }
                        if (!evaluated.contains(temp)) evaluated.add(temp);
                    }
                } catch (Exception e) {
                    Log.e("GamePRE", "Exception: " + e.toString() + "\n" + e.getMessage());
                }
            }
        }
    }
    public void nextRound(){
        //continue with new round
        evaluate();
        if (ThirtyOne.spieler.size()>1){
            //playerList contains more than one player → start new round
            Intent in = new Intent(this,GameSS.class);
            startActivity(in);
            finish();
        }
        //endGame
        else {
            if (!ThirtyOne.spieler.isEmpty()&&!ThirtyOne.verlierer.contains(ThirtyOne.spieler.get(0)))
                ThirtyOne.verlierer.add(ThirtyOne.spieler.get(0));
            Intent in = new Intent(this,EndOfGame.class);
            startActivity(in);
            finish();
        }
    }
    public void alertMessage() {
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case DialogInterface.BUTTON_POSITIVE:
                        // Yes button clicked
                        Intent in = new Intent(getApplicationContext(), MainMenu.class);
                        startActivity(in);
                        finish();
                        break;
                    case DialogInterface.BUTTON_NEGATIVE:
                        break;
                    default: break;
                }
            }
        };
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.MainMenuDialog).setPositiveButton(R.string.Yes, dialogClickListener).setNegativeButton(R.string.No, dialogClickListener).show();
    }

}

