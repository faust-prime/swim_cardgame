package com.company.schwimmen;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;

public class MainMenu extends AppCompatActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Displayrientation setzen
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);

        //Title-Bar entfernen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main_menu);

        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);

        Button button_play = (Button) findViewById(R.id.button_play);

        if (button_play!=null) button_play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startGame();
            }
        });
        ImageButton button_settings = (ImageButton) findViewById(R.id.button_settings);
        if (button_settings!=null) button_settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSettings();
            }
        });

        ImageButton button_highscore = (ImageButton) findViewById(R.id.button_highscore);
        if (button_highscore!=null) button_highscore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openHighScores();
            }
        });
    }
    public void openSettings(){
        Intent in = new Intent(getApplicationContext(), Settings.class);
        startActivity(in);
        finish();
    }
    public void openHighScores(){
        Intent in = new Intent(getApplicationContext(), HighScore.class);
        startActivity(in);
        finish();
    }
    public void startGame(){
        Intent in = new Intent(getApplicationContext(), GamePRE.class);
        startActivity(in);
        finish();
    }
}