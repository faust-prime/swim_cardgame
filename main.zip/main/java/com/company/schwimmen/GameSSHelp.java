package com.company.schwimmen;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.TextView;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */



public class GameSSHelp extends Activity {
    static String txt="";

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);

        //Title-Bar entfernen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //Content des Fensters laden (xml Datei)
        setContentView(R.layout.activity_game_pre);

        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);

        //statusText with active.name inside
        setContent();
        setContentView(R.layout.activity_game_sp_help);
        setBtnListeners();
    }

    public void setBtnListeners(){
        ImageButton btnHelp = (ImageButton) findViewById(R.id.btnHelp);
        if (btnHelp!=null)
            btnHelp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();
                }
            });
    }
    public void setContent(){
        TextView txtName = (TextView) findViewById(R.id.spielername);
        if (txtName != null) {
            //aktiven Spielernamen und seine Leben anzeigen
            TextView txtPunkte = (TextView) findViewById(R.id.punkte);
            String leben = ThirtyOne.active.leben + "";
            String o = "(";
            String c = ")";
            switch (leben) {
                case "3":   leben = o + "♡♡♡" + c;  break;
                case "2":   leben = o + "♡♡" + c;   break;
                case "1":   leben = o + "♡" + c;    break;
                case "0":
                    //FIXME show swimming, else can be deleted
                    //leben = o+"0♡ " + getResources().getString(R.string.swimming)+c;
                    leben = o + "0♡" + c;
                    break;
                default:    leben = o + leben + "♡" + c;    break;
            }
            leben = ThirtyOne.active.name + leben;
            txtName.setText(leben);
            txt = leben;
        }
    }
}
