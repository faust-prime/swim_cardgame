package com.company.schwimmen;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class EndOfGame extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Displayrientation setzen
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);

        //Title-Bar entfernen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);

        setContentView(R.layout.activity_end_of_game);
        setListeners();
        setContent();
    }
    public void setListeners(){
        ImageButton btnMenu = (ImageButton) findViewById(R.id.btnMainMenu);
        if (btnMenu!=null) btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertMessage();
            }
        });

//        ImageButton btnNext = (ImageButton) findViewById(R.id.btnNext);
//        if (btnNext!=null) btnNext.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                backToMenu();
//            }
//        });

    }
    public void setContent() {
        TextView roundCount = (TextView) findViewById(R.id.titleTextEoGCount);
        String message = " #" + ThirtyOne.roundCount + " " + getResources().getString(R.string.EoGCount);
        if (roundCount != null) roundCount.setText(message);

        ArrayList<TextView> text = new ArrayList<>();
        text.add((TextView) findViewById(R.id.EoG_PlayerName1));
        text.add((TextView) findViewById(R.id.EoG_PlayerName2));
        text.add((TextView) findViewById(R.id.EoG_PlayerName3));
        text.add((TextView) findViewById(R.id.EoG_PlayerName4));
        text.add((TextView) findViewById(R.id.EoG_PlayerName5));
        text.add((TextView) findViewById(R.id.EoG_PlayerName6));
        text.add((TextView) findViewById(R.id.EoG_PlayerName7));
        text.add((TextView) findViewById(R.id.EoG_PlayerName8));
        text.add((TextView) findViewById(R.id.EoG_PlayerName9));


        String spielerPunkte;
        int ranking = ThirtyOne.verlierer.size();

        for (Player temp : ThirtyOne.verlierer) {
            String leben = temp.leben+"";
            String o = " (";
            String c = " )";
            switch (leben) {
                case "3":
                    leben = o+"♡♡♡"+c;
                    break;
                case "2":
                    leben = o+"♡♡"+c;
                    break;
                case "1":
                    leben = o+"♡"+c;
                    break;
                default:
                    leben = o+leben+"♡"+c;
                    break;
            }
            if (ranking > 3) spielerPunkte = getResources().getString(R.string.rank) + ranking;
            else if (ranking == 3) spielerPunkte = getResources().getString(R.string.third) + " " + getResources().getString(R.string.place);
            else if (ranking == 2) spielerPunkte = getResources().getString(R.string.second) + " " + getResources().getString(R.string.place);
            else                   spielerPunkte = getResources().getString(R.string.first) + " " + getResources().getString(R.string.place);
            String remain = " "+ getResources().getString(R.string.lifesRemain);
            spielerPunkte += getResources().getString(R.string.is) + " " + temp.name + ":"+ leben+remain+"\n"+o;
            //FIXME insert hat xyz Runden mitgespielt
            while (!temp.points.isEmpty()) {

                spielerPunkte += temp.points.remove(0).toString();

                if (!temp.points.isEmpty()) spielerPunkte += ", ";
                else spielerPunkte += " " + getResources().getString(R.string.points) + "."+c;
            }
            if (text.get(0) != null) text.remove(0).setText(spielerPunkte);
            ranking--;
        }
    }
    public void alertMessage() {
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case DialogInterface.BUTTON_POSITIVE:
                        backToMenu();
                        break;
                    case DialogInterface.BUTTON_NEGATIVE:
                        break;
                    default: break;
                }
            }
        };
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.MainMenuDialog).setPositiveButton(R.string.Yes, dialogClickListener).setNegativeButton(R.string.No, dialogClickListener).show();
    }
    public void backToMenu(){
        Intent in = new Intent(getApplicationContext(), MainMenu.class);
        startActivity(in);
        finish();
        String message = "";
        if (!ThirtyOne.verlierer.isEmpty()) message = ThirtyOne.verlierer.get(ThirtyOne.verlierer.size()-1).name +" "+ getResources().getString(R.string.won);
        Toast info = Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG);
        info.setGravity(Gravity.CENTER,0,0);
        info.show();
    }
}
