package com.company.schwimmen;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;

public class GameSS extends Activity {
    //index to swapCards, 100 means no Card selected
    static int handIndex = 100;
    static int fieldIndex= 100;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Displayrientation setzen
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);

        //Title-Bar entfernen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        //Content des Fensters laden (xml Datei)
        setContentView(R.layout.activity_game_sp);
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);

        //intialize first round
        setBtnListeners();
        startGame();
    }
    public void setBtnListeners(){
        TextView frame = (TextView) findViewById(R.id.fullscreen_content);
        if (frame!=null){
            frame.setClickable(false);
            frame.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    openPlayerHand();
                }
            });
        }

        //Aktionsbuttons
        ImageButton btnCheck = (ImageButton) findViewById(R.id.btnCheck);
        if (btnCheck!=null)
            btnCheck.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    check();
                }
            });

        ImageButton btnMenu = (ImageButton) findViewById(R.id.btnMenu);
        if (btnMenu!=null)
            btnMenu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    alertMessage();
                }
            });

        ImageButton btnClose = (ImageButton) findViewById(R.id.btnClose);
        if (btnClose!=null)
            btnClose.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    close();
                }
            });

        ImageButton btnSwapAll = (ImageButton) findViewById(R.id.btnSwapAll);
        if (btnSwapAll!=null)
            btnSwapAll.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    swapAll();
                }
            });

        ImageButton btnFinish = (ImageButton) findViewById(R.id.btnNext);
        if (btnFinish!=null)
            btnFinish.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (ThirtyOne.actionMade) next();
                }
            });

        final ImageButton btnBack = (ImageButton) findViewById(R.id.btnUndo);
        if (btnBack!=null){
            btnBack.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    undo();
                }
            });
        }

        ImageButton btnEnd = (ImageButton) findViewById(R.id.btnEndRound);
        if (btnEnd!=null) btnEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                endGame();
            }
        });


        //Handbuttons
        ImageButton btnHandOne = (ImageButton) findViewById(R.id.handOne);
        if (btnHandOne!=null)
            btnHandOne.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    handIndex =0;
                    if (fieldIndex <=2) swapCard(0, fieldIndex);
                }
            });
        ImageButton btnHandTwo = (ImageButton) findViewById(R.id.handTwo);
        if (btnHandTwo!=null)
            btnHandTwo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    handIndex =1;
                    if (fieldIndex <=2) swapCard(1, fieldIndex);
                }
            });
        ImageButton btnHandThree = (ImageButton) findViewById(R.id.handThree);
        if (btnHandThree!=null)
            btnHandThree.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    handIndex =2;
                    if (fieldIndex <=2) swapCard(2, fieldIndex);
                }
            });


        //Feldbuttons
        ImageButton btnField0 = (ImageButton) findViewById(R.id.fieldOne);
        if (btnField0!=null)
            btnField0.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fieldIndex =0;
                    if (handIndex <=2) swapCard(handIndex, 0);
                }
            });
        ImageButton btnField1 = (ImageButton) findViewById(R.id.fieldTwo);
        if (btnField1!=null)
            btnField1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fieldIndex =1;
                    if (handIndex <=2) swapCard(handIndex, 1);
                }
            });
        ImageButton btnField2 = (ImageButton) findViewById(R.id.fieldThree);
        if (btnField2!=null)
            btnField2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fieldIndex =2;
                    if (handIndex <=2) swapCard(handIndex, 2);
                }
            });

        ImageButton btnHelp = (ImageButton) findViewById(R.id.btnHelp);
        if (btnHelp!=null)
            btnHelp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent in = new Intent(getApplicationContext(), GameSSHelp.class);
                    startActivity(in);
                }
            });
    }
    public void startGame() {
        ThirtyOne.roundCount++;
        ThirtyOne.activePlayerNo =1;
        ThirtyOne.closedByPlayerNo=0;
        ThirtyOne.checkedByPlayerNo = 0;
        ThirtyOne.checked= false;
        ThirtyOne.closed= false;
        ThirtyOne.allSwapped= false;
        ThirtyOne.actionMade=false;
        ThirtyOne.gameOver = false;
        ThirtyOne.firstPlayerTurn =true;
        ThirtyOne.spieler.add(new Player(null));
        ThirtyOne.dealCards();
        ThirtyOne.board = ThirtyOne.spieler.remove(ThirtyOne.spieler.size()-1);
        ThirtyOne.active = ThirtyOne.spieler.remove(0);
        if (!ThirtyOne.spieler.contains(ThirtyOne.active)) ThirtyOne.spieler.add(ThirtyOne.active);

        undo();
        reloadButtons();
        backgroundField();
        backgroundHand();
        cardButtonsClickable(false);
        //FIXME firstPlayerCPU
    }
    //Hintergrundmethoden
    public void startButtonAnimation(ImageButton b, TextView t, String message) {
        Animation textAnimation = new AlphaAnimation(0.0f, 1.0f);
        textAnimation.setDuration(700); //You can manage the time of the blink with this parameter
        textAnimation.setStartOffset(20);
        textAnimation.setRepeatMode(Animation.REVERSE);
        textAnimation.setRepeatCount(2);
        if (t!=null&&message!=null) {
            t.setText(message);
            t.setAnimation(textAnimation);
        }
//        Animation buttonAnimation;
//        AnimationSet animationSet = new AnimationSet(true);
//        ArrayList<ImageButton> actionBtn = new ArrayList<>();
//        actionBtn.add((ImageButton) findViewById(R.id.btnschieben));
//        actionBtn.add((ImageButton) findViewById(R.id.btnclose));
//        actionBtn.add((ImageButton) findViewById(R.id.btnswitch_all));
//        for(ImageButton temp:actionBtn){
//            if(temp!=null) {
//                if (temp==b){
//                    if (b.getAnimation()!=null){
//                        return;
//                    }
//                    else{
//                        buttonAnimation = new ScaleAnimation(1.0f, 1.15f, 1.0f, 1.15f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
//                        buttonAnimation.setDuration(700); //You can manage the time of the blink with this parameter
//                        buttonAnimation.setStartOffset(0);
//                        buttonAnimation.setRepeatMode(Animation.REVERSE);
//                        buttonAnimation.setRepeatCount(Animation.INFINITE);
//                        if (b!=null) b.setAnimation(buttonAnimation);
//                        animationSet.addAnimation(buttonAnimation);
//                    }
//                }
//            }
//        }
        Animation buttonAnimation = new ScaleAnimation(1.0f, 1.15f, 1.0f, 1.15f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        buttonAnimation.setDuration(700); //You can manage the time of the blink with this parameter
        buttonAnimation.setStartOffset(0);
        buttonAnimation.setRepeatMode(Animation.REVERSE);
        buttonAnimation.setRepeatCount(Animation.INFINITE);
        if (b!=null) b.setAnimation(buttonAnimation);

        AnimationSet animationSet = new AnimationSet(true);
        animationSet.setFillAfter(false);
        animationSet.setFillBefore(true);
        animationSet.setFillEnabled(true);
        animationSet.addAnimation(textAnimation);
        animationSet.addAnimation(buttonAnimation);
        animationSet.start();
    }
    public long alphaFade(ImageButton btn, float from, float to, long offset, boolean fillBefore){
        Animation fade = new AlphaAnimation(from, to);
        fade.setStartOffset(offset);
        fade.setDuration(Settings.animationSpeed);
        fade.setRepeatCount(0);
        fade.setFillBefore(fillBefore);
        fade.setFillAfter(true);
        if (btn!=null) btn.startAnimation(fade);
        return fade.getDuration()*(1+fade.getRepeatCount()) +fade.getStartOffset();
    }
    //FIXME @julian fadeOutFunction
//    public long alphaFade(final ImageButton btn, float from, float to, final long offset, final boolean fillBefore){
//
//        final Animation fade = new AlphaAnimation(from, to);
//        fade.setFillBefore(fillBefore);
//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                //fade.setStartOffset(offset);
//                fade.setDuration(Settings.animationSpeed);
//                fade.setRepeatCount(0);
//                fade.setFillAfter(true);
//                if (btn!=null) btn.startAnimation(fade);
//            }
//        }, offset);
//        return fade.getDuration()*(1+fade.getRepeatCount()) +fade.getStartOffset();
//    }

    public void validActionAnimation(){
        nextBtnColorGreen(true);
        cardButtonsClickable(false);
        startButtonAnimation((ImageButton) findViewById(R.id.btnNext),null,null);
        pointsAndBackground();
    }
    public void stopAnimations() {
        //fixme txtStatus
//        TextView t = (TextView) findViewById(R.id.txtStatus);
//        if (t!=null) t.setText("");
        ArrayList<ImageButton> buttons = new ArrayList<>();
        buttons.add((ImageButton) findViewById(R.id.btnCheck));
        buttons.add((ImageButton) findViewById(R.id.btnClose));
        buttons.add((ImageButton) findViewById(R.id.btnSwapAll));
        for(ImageButton temp:buttons){
            if(temp!=null&&!ThirtyOne.actionMade) temp.clearAnimation();
        }
        buttons.clear();
    }
    public void alertMessage() {
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case DialogInterface.BUTTON_POSITIVE:
                        // Yes button clicked
                        Intent in = new Intent(getApplicationContext(), GamePRE.class);
                        startActivity(in);
                        finish();
                        break;
                    case DialogInterface.BUTTON_NEGATIVE:
                        break;
                    default: break;
                }
            }
        };
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.MainMenuDialog).setPositiveButton(R.string.Yes, dialogClickListener).setNegativeButton(R.string.No, dialogClickListener).show();
    }
    public void reloadButtons(){
        new Hand(ThirtyOne.board,(ImageButton) findViewById(R.id.fieldOne),  (ImageButton) findViewById(R.id.fieldTwo), (ImageButton) findViewById(R.id.fieldThree));
        new Hand(ThirtyOne.active,(ImageButton) findViewById(R.id.handOne),  (ImageButton) findViewById(R.id.handTwo), (ImageButton) findViewById(R.id.handThree));
    }
    public String pointsAndBackground(){

        String pointsDisplay = getResources().getString(R.string.points)+ ": "+ ThirtyOne.active.adjustedHandValue();
        String txt = ThirtyOne.active.leben+"";
        //FIXME show swimming, else can be deleted
        switch (txt) {
            case "3":
                txt = " ♡♡♡";
                break;
            case "2":
                txt = " ♡♡";
                break;
            case "1":
                txt = " ♡";
                break;
            default:
                txt = txt+" ♡";
                break;
        }
        //Name+♡♡♡
        TextView txtName = (TextView) findViewById(R.id.spielername);
        if (txtName!=null) {
            txt = ThirtyOne.active.name + txt;
            txtName.setText(txt);
        }

        //Punktestring
        TextView txtPunkte = (TextView) findViewById(R.id.punkte);
        if (!ThirtyOne.active.cpu) {
            if (txtPunkte!=null) txtPunkte.setText(pointsDisplay);
        }

        //bei 31 oder 3xA: Button zum Beenden einblenden
        TextView endTxt = (TextView) findViewById(R.id.txtEndGame);
        ImageButton endRound = (ImageButton) findViewById(R.id.btnEndRound);
        if (endRound!=null && endTxt !=null) {
            if (ThirtyOne.active.handValue >= ThirtyOne.fireValue){
                endRound.setVisibility(View.VISIBLE);
                endTxt.setVisibility(View.VISIBLE);
                alphaFade(endRound,0f,1f,0,true);
                endRound.setClickable(true);
                if (ThirtyOne.active.handValue == ThirtyOne.fireValue) endTxt.setText(getResources().getString(R.string.actionFire));
                else  endTxt.setText(getResources().getString(R.string.action31));
                startButtonAnimation(endRound, (TextView)findViewById(R.id.spielername), pointsDisplay);
            }
            else {
                endRound.setVisibility(View.INVISIBLE);
                endTxt.setVisibility(View.INVISIBLE);
                endRound.clearAnimation();
                endRound.setClickable(false);
            }
        }
        return txt;
    }
    public void cardButtonsClickable(boolean bool){
        ArrayList<ImageButton> buttons = new ArrayList<>();
        buttons.add((ImageButton) findViewById(R.id.fieldThree));
        buttons.add((ImageButton) findViewById(R.id.fieldTwo));
        buttons.add((ImageButton) findViewById(R.id.fieldOne));
        buttons.add((ImageButton) findViewById(R.id.handThree));
        buttons.add((ImageButton) findViewById(R.id.handTwo));
        buttons.add((ImageButton) findViewById(R.id.handOne));
        for(ImageButton temp:buttons){
            if(temp!=null) {
                temp.setEnabled(bool);
                temp.setClickable(bool);
            }
        }
        buttons.clear();
    }
    public void nextBtnColorGreen(boolean valid){
        ArrayList<ImageButton> buttons = new ArrayList<>();
        buttons.add((ImageButton) findViewById(R.id.btnCheck));
        buttons.add((ImageButton) findViewById(R.id.btnClose));
        buttons.add((ImageButton) findViewById(R.id.btnSwapAll));
        for (ImageButton temp : buttons) {
            if (valid) {
                alphaFade(temp,1f,0.333333f,0,true);
                temp.setEnabled(false);
                temp.setClickable(false);
            }
            else if (temp!=null && temp.getAlpha()!=0f){
                alphaFade(temp,0.333333f,1f,0,true);
                temp.setEnabled(true);
                temp.setClickable(true);
            }

        } buttons.clear();
        //FIXME Undo animation
        ImageButton btnUndo = (ImageButton) findViewById(R.id.btnUndo);
        if (ThirtyOne.active.cpu) {
            if (btnUndo!=null) btnUndo.setVisibility(View.GONE);
        } else if (btnUndo!=null) btnUndo.setVisibility(View.VISIBLE);

        String imageName;
        //FIXME @Julian nextBtn nach Aktion färben!?
//        if      (!valid&&closed) imageName="close_grey";
//        else if (valid&&closed) imageName = "close_green";
//        else if (valid&&checked) imageName = "check_green";
//        else if (!valid&&checked) imageName = "check_grey";
        if (valid) {
            imageName  = "tick_green";
            if ((btnUndo!=null && btnUndo.getAlpha()<= 1f) && !(ThirtyOne.allSwapped && ThirtyOne.firstPlayerTurn)) {
                btnUndo.setClickable(true);
                alphaFade(btnUndo,0f,1f,0,true);
            }
        }
        else {
            imageName = "tick_black";
            if (btnUndo!=null && btnUndo.getAlpha()>=0f) alphaFade(btnUndo,1f,0f,0,true);
            if (btnUndo!=null) btnUndo.setClickable(false);
        }
        ImageButton btnFinishTurn = (ImageButton) findViewById(R.id.btnNext);
        if (btnFinishTurn!=null){
            long offset = alphaFade(btnFinishTurn,1f,0f,0,true);
            Context context = btnFinishTurn.getContext();
            int id = context.getResources().getIdentifier(imageName, "drawable", context.getPackageName());
            btnFinishTurn.setImageResource(id);
            alphaFade(btnFinishTurn,0f,1f,offset,true);
        }
    }
    public void backgroundHand(){
        ArrayList<ImageButton> buttons = new ArrayList<>();
        buttons.add((ImageButton) findViewById(R.id.handOne));
        buttons.add((ImageButton) findViewById(R.id.handTwo));
        buttons.add((ImageButton) findViewById(R.id.handThree));
        for (ImageButton btn:buttons){
            if (btn!=null){
                Context c = btn.getContext();
                int id = c.getResources().getIdentifier("cardback", "mipmap", c.getPackageName());
                btn.setImageResource(id);
            }
        }
        TextView frame = (TextView) findViewById(R.id.fullscreen_content);
        if (frame!=null) frame.setClickable(true);

        if (!ThirtyOne.active.cpu) {
            String nachricht = ThirtyOne.active.name +" "+ getResources().getString(R.string.actionNext) +"\n"+
            getResources().getString(R.string.actionNext2ndLine);
            startButtonAnimation(null, (TextView) findViewById(R.id.spielername), nachricht);
            //FIXME nextText: previous CPU
        }

        TextView punkte = (TextView) findViewById(R.id.punkte);
        if (punkte!=null) punkte.setText("");

        ImageButton btnback = (ImageButton) findViewById(R.id.btnUndo);
        if (btnback!=null)  alphaFade(btnback,1f,0f,0,true);
    }
    public void backgroundField(){
        ArrayList<ImageButton> buttons = new ArrayList<>();
        buttons.add((ImageButton) findViewById(R.id.fieldOne));
        buttons.add((ImageButton) findViewById(R.id.fieldTwo));
        buttons.add((ImageButton) findViewById(R.id.fieldThree));
        for (ImageButton btn:buttons){
            if (btn!=null){
                Context c = btn.getContext();
                int id = c.getResources().getIdentifier("cardback", "mipmap", c.getPackageName());
                btn.setImageResource(id);
            }
        }
    }
    public void openPlayerHand(){
        if (!ThirtyOne.active.cpu) reloadButtons();
        if(ThirtyOne.firstPlayerTurn)  {
            cardButtonsClickable(false);
            backgroundField();
        }
        else  cardButtonsClickable(true);
        pointsAndBackground();
        stopAnimations();
        nextBtnColorGreen(false);
        TextView frame = (TextView) findViewById(R.id.fullscreen_content);
        if (frame!=null) frame.setClickable(false);
    }

    //todo erhalt checked wenn karten geswappt, zurückgeswappt und dann gecheckt wird
    //Spiel Aktionen
    public void swapCard(int player, int field){
        stopAnimations();
        ArrayList<ImageButton> hand = new ArrayList<>();
        hand.add((ImageButton) findViewById(R.id.handOne));
        hand.add((ImageButton) findViewById(R.id.handTwo));
        hand.add((ImageButton) findViewById(R.id.handThree));
        ArrayList<ImageButton> feld = new ArrayList<>();
        feld.add((ImageButton) findViewById(R.id.fieldOne));
        feld.add((ImageButton) findViewById(R.id.fieldTwo));
        feld.add((ImageButton) findViewById(R.id.fieldThree));
        ImageButton alte = hand.get(player);
        ImageButton neue = feld.get(field);
        //FIXME @Julian fade out
        long offset = alphaFade(neue,1f,0f,alphaFade(alte,1f,0f,0,true),true);

        //swap ThirtyOne.cards
        Card alt = ThirtyOne.active.hand.remove(player);
        Card neu = ThirtyOne.board.hand.remove(field);
        ThirtyOne.active.hand.add(player,neu);
        ThirtyOne.board.hand.add(field,alt);
        ThirtyOne.actionMade = true;
        ThirtyOne.checked=false;
        fieldIndex =field;
        handIndex =player;
        reloadButtons();
        //fade in
        alphaFade(neue,0f,1f,alphaFade(alte,0f,1f,offset,false),false);

        String message = "\n"+getResources().getString(R.string.actionSwapCard);
//        TextView txtName = (TextView) findViewById(R.id.spielername);
//        if (txtName!=null) {
//            message = txtName.getText()+"\n"+getResources().getString(R.string.actionSwapCard);
//            txtName.setText(message);
//        }
        validActionAnimation();
        startButtonAnimation(null, (TextView) findViewById(R.id.spielername),pointsAndBackground()+message);
    }
    public void swapAll() {
        stopAnimations();
        handIndex = fieldIndex =100;
        ArrayList<ImageButton> karten = new ArrayList<>();
        karten.add((ImageButton) findViewById(R.id.handOne));
        karten.add((ImageButton) findViewById(R.id.handTwo));
        karten.add((ImageButton) findViewById(R.id.handThree));
        karten.add((ImageButton) findViewById(R.id.fieldOne));
        karten.add((ImageButton) findViewById(R.id.fieldTwo));
        karten.add((ImageButton) findViewById(R.id.fieldThree));
        long offset=0;
        //FIXME @Julian fade out
        for(ImageButton temp:karten){
            offset = alphaFade(temp,1f,0f,offset,true);
        }
        //swap
        ArrayList<Card> alt= ThirtyOne.active.hand;
        ThirtyOne.active.hand = ThirtyOne.board.hand;
        ThirtyOne.board.hand = alt;
        ThirtyOne.actionMade =true;
        ThirtyOne.allSwapped =true;
        ThirtyOne.checked=false;
        reloadButtons();
        //fade in
        for(ImageButton temp:karten){
            offset = alphaFade(temp,0f,1f,offset,false);
        }
        String message = "\n"+getResources().getString(R.string.actionSwapAll);
//        TextView txtName = (TextView) findViewById(R.id.spielername);
//        if (txtName!=null) {
//            message = txtName.getText()+"\n"+getResources().getString(R.string.actionSwapAll);
//            txtName.setText(message);
//        }
        validActionAnimation();
        startButtonAnimation((ImageButton) findViewById(R.id.btnSwapAll), (TextView) findViewById(R.id.spielername),pointsAndBackground()+message);
    }
    public void check(){
        stopAnimations();
        handIndex = fieldIndex =100;
        if (!ThirtyOne.checked){
            ThirtyOne.checked =true;
            ThirtyOne.checkedByPlayerNo = ThirtyOne.activePlayerNo;
        }
        ThirtyOne.actionMade = true;
        String message = "\n"+getResources().getString(R.string.actionCheck);
//        TextView txtName = (TextView) findViewById(R.id.spielername);
//        if (txtName!=null) {
//            message = txtName.getText()+"\n"+getResources().getString(R.string.actionCheck);
//            txtName.setText(message);
//        }
        validActionAnimation();
        startButtonAnimation((ImageButton) findViewById(R.id.btnCheck), (TextView) findViewById(R.id.spielername),pointsAndBackground()+message);
    }
    public void close(){
        stopAnimations();
        if (!ThirtyOne.closed){
            ThirtyOne.closed =true;
            ThirtyOne.closedByPlayerNo = ThirtyOne.activePlayerNo;
        }
        ThirtyOne.actionMade = true;
        ThirtyOne.checked=false;
        handIndex = fieldIndex =100;
        String message = "\n"+getResources().getString(R.string.actionClose);
//        TextView txtName = (TextView) findViewById(R.id.spielername);
//        if (txtName!=null) {
//            message = txtName.getText()+"\n"+getResources().getString(R.string.actionClose);
//            txtName.setText(message);
//        }
        validActionAnimation();
        startButtonAnimation((ImageButton) findViewById(R.id.btnClose), (TextView) findViewById(R.id.spielername),pointsAndBackground()+message);
    }
    public void uncheck(){
        ThirtyOne.checked=false;
        ThirtyOne.checkedByPlayerNo =0;
    }
    public void unclose(){
        ThirtyOne.closed=false;
        ThirtyOne.closedByPlayerNo =0;
    }
    public void dealNewBoard(){
        //fade out field_0
        final int dauer = 100;
        ImageButton buttonField0 = (ImageButton) findViewById(R.id.fieldOne);
        if (buttonField0!=null) buttonField0.animate().setDuration(dauer).alpha(0f);

        //fade out field_1 after 150ms
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                ImageButton buttonField1 = (ImageButton) findViewById(R.id.fieldTwo);
                buttonField1.animate()
                        .setDuration(dauer)
                        .alpha(0f);

            }
        },dauer+50);
        //fade out field_2 after 300ms
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                ImageButton buttonField2 = (ImageButton) findViewById(R.id.fieldThree);
                buttonField2.animate()
                        .setDuration(dauer)
                        .alpha(0f);

            }
        }, dauer+2*50);

        //deal new field ThirtyOne.cards
        if (ThirtyOne.cards.size()>=3){
            ThirtyOne.board.hand.clear();
            ThirtyOne.board.hand.add(ThirtyOne.cards.remove(0));
            ThirtyOne.board.hand.add(ThirtyOne.cards.remove(0));
            ThirtyOne.board.hand.add(ThirtyOne.cards.remove(0));
        }
        new Hand(ThirtyOne.board,(ImageButton) findViewById(R.id.fieldOne),  (ImageButton) findViewById(R.id.fieldTwo), (ImageButton) findViewById(R.id.fieldThree));

        //fade in buttons after 300ms(fade_out) and fade in +150 and +300
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                //fade in field_0
                ImageButton btnfield0 = (ImageButton) findViewById(R.id.fieldOne);
                btnfield0.animate()
                        .setDuration(dauer)
                        .alpha(1f);

                //fade in field_1 after +150ms
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        ImageButton btnfield1 = (ImageButton) findViewById(R.id.fieldTwo);
                        btnfield1.animate()
                                .setDuration(dauer)
                                .alpha(1f);

                    }
                }, dauer+4*50);

                //fade in field_2 after +300ms
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        ImageButton btnfield2 = (ImageButton) findViewById(R.id.fieldThree);
                        btnfield2.animate()
                                .setDuration(dauer)
                                .alpha(1f);

                    }
                }, dauer+5*50);
            }
        }, dauer+3*50);
        //FIXME erhalt checked
        ThirtyOne.checked =false;
        ThirtyOne.checkedByPlayerNo =0;
    }
    public static void fire (Player p, ArrayList<Player> liste){
        for (Player temp:liste)
            if (temp!=p) temp.looseOneLife();
    }
    public void endGame(){
        handIndex = fieldIndex =100;
        ThirtyOne.gameOver = ThirtyOne.firstPlayerTurn =true;

        Intent in = new Intent(getApplicationContext(), EndOfRound.class);
        startActivity(in);
        finish();
    }
    public void undo(){
        if      (handIndex <=2 && fieldIndex <=2)                         {swapCard(handIndex, fieldIndex);          ThirtyOne.actionMade =false;}
        else if (ThirtyOne.closedByPlayerNo == ThirtyOne.activePlayerNo)  {unclose();                                ThirtyOne.actionMade =false;}
        else if (!ThirtyOne.firstPlayerTurn && ThirtyOne.allSwapped)      {swapAll();  ThirtyOne.allSwapped =false;  ThirtyOne.actionMade =false;}
        else if (ThirtyOne.checkedByPlayerNo == ThirtyOne.activePlayerNo) {uncheck();                                ThirtyOne.actionMade =false;}

        //animate
        if (!ThirtyOne.actionMade) nextBtnColorGreen(false);
        if (ThirtyOne.firstPlayerTurn) cardButtonsClickable(false);
        else cardButtonsClickable(true);
        handIndex = fieldIndex =100;
        stopAnimations();
        pointsAndBackground();
    }
    public void next(){
        backgroundHand();
        if (!ThirtyOne.spieler.contains(ThirtyOne.active)) ThirtyOne.spieler.add(ThirtyOne.active);
        ThirtyOne.activePlayerNo = (ThirtyOne.activePlayerNo % ThirtyOne.spieler.size()) +1;
        ThirtyOne.gameOver = false;
        ThirtyOne.allSwapped =false;
        ThirtyOne.actionMade =false;
        ThirtyOne.firstPlayerTurn = false;
        handIndex = fieldIndex =100;
        if (ThirtyOne.closed && ThirtyOne.closedByPlayerNo == ThirtyOne.activePlayerNo)           { endGame(); ThirtyOne.gameOver =true;}
        if (ThirtyOne.checked&& ThirtyOne.checkedByPlayerNo == ThirtyOne.activePlayerNo)          { dealNewBoard(); }
        if (!ThirtyOne.gameOver) {
            ThirtyOne.active = ThirtyOne.spieler.remove(0);
            if (!ThirtyOne.spieler.contains(ThirtyOne.active)) ThirtyOne.spieler.add(ThirtyOne.active);


            if (ThirtyOne.active.cpu){
                //TODO implement KI
                final int w8 = 700;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        ImageButton check = (ImageButton) findViewById(R.id.btnCheck);
                        //if (check!=null) check.performClick();

                        swapCard(ThirtyOne.active.worstCardIndex(),ThirtyOne.board.boardImprovementIndex());
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                ImageButton next = (ImageButton) findViewById(R.id.btnNext);
                                if (next!=null) next.performClick();
                            }
                        },w8);
                    }
                },w8);

            }
        }
    }

}