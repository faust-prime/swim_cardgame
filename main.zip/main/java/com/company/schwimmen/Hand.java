package com.company.schwimmen;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ImageButton;

class Hand{
    //Constructor used in EndOfRound:
    Hand(Player spieler, ImageView a, ImageView b, ImageView c, TextView text) {
        if (spieler != null) {
            String leben = spieler.leben+"♡";
            if (spieler.leben==3) leben="♡♡♡";
            else if (spieler.leben==2) leben= "♡♡";
            else if (spieler.leben==0) leben= "0♡ " +a.getResources().getString(R.string.swims);
            if (spieler.hand.size()>2) {
                String message = spieler.name + " "+leben+"\n" + spieler.adjustedHandValue() + " " + a.getResources().getString(R.string.points);
                //TODO Show last player in Game
                if (EndOfRound.min==spieler.handValue) {
                    message += "\n"+ a.getResources().getString(R.string.EoRlooseALife);
                    if  (spieler.leben==0) message += "\n"+ a.getResources().getString(R.string.EoRlooseGame);
                }
                if (text != null) {
                    text.setText(message);
                    text.setVisibility(View.VISIBLE);
                    a.setVisibility(View.VISIBLE);
                    b.setVisibility(View.VISIBLE);
                    c.setVisibility(View.VISIBLE);
                    a.setImageResource(a.getResources().getIdentifier(spieler.hand.get(0).suit.toString()+spieler.hand.get(0).rank +"", "mipmap", a.getContext().getPackageName()));
                    b.setImageResource(b.getResources().getIdentifier(spieler.hand.get(1).suit.toString()+spieler.hand.get(1).rank +"", "mipmap", b.getContext().getPackageName()));
                    c.setImageResource(c.getResources().getIdentifier(spieler.hand.get(2).suit.toString()+spieler.hand.get(2).rank +"", "mipmap", c.getContext().getPackageName()));
                }
            }
        }
        else {
            text.setVisibility(View.GONE);
            a.setVisibility(View.GONE);
            b.setVisibility(View.GONE);
            c.setVisibility(View.GONE);
        }

    }

    //Constuctor used in GameSS:
    Hand(Player spieler, ImageButton a, ImageButton b, ImageButton c) {
        if (spieler !=null && a!=null && b!=null && c!=null && spieler.hand.size()>2) {
            a.setImageResource(a.getResources().getIdentifier(spieler.hand.get(0).suit.toString()+spieler.hand.get(0).rank +"", "mipmap", a.getContext().getPackageName()));
            b.setImageResource(b.getResources().getIdentifier(spieler.hand.get(1).suit.toString()+spieler.hand.get(1).rank +"", "mipmap", b.getContext().getPackageName()));
            c.setImageResource(c.getResources().getIdentifier(spieler.hand.get(2).suit.toString()+spieler.hand.get(2).rank +"", "mipmap", c.getContext().getPackageName()));
        }
    }
    }
