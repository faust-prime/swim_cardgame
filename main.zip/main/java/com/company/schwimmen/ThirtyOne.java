package com.company.schwimmen;

import java.util.ArrayList;
import java.util.Collections;

class ThirtyOne {
    static ArrayList<Player> spieler = new ArrayList<>();
    static ArrayList<Player> verlierer = new ArrayList<>();
    static ArrayList<Card> cards = new ArrayList<>();
    static boolean check, checked, closed, allSwapped, actionMade, firstPlayerTurn, gameOver = false;
    static int activePlayerNo, closedByPlayerNo, checkedByPlayerNo;
    //Feuer: drei Asse werden so bewertet
    static float fireValue = 30.5f + new Card(14,'s').rank;

    static Player active, board;
    static int roundCount;
    static void dealCards() {
        cards.clear(); //altes Deck löschen
                    //Card(typ,sym)
        cards.add(new Card(7,'s'));
        cards.add(new Card(7,'c'));
        cards.add(new Card(7,'h'));
        cards.add(new Card(7,'d'));

        cards.add(new Card(8,'s'));
        cards.add(new Card(8,'c'));
        cards.add(new Card(8,'h'));
        cards.add(new Card(8,'d'));

        cards.add(new Card(9,'s'));
        cards.add(new Card(9,'c'));
        cards.add(new Card(9,'h'));
        cards.add(new Card(9,'d'));

        cards.add(new Card(10,'s'));
        cards.add(new Card(10,'c'));
        cards.add(new Card(10,'h'));
        cards.add(new Card(10,'d'));

        cards.add(new Card(11,'s'));
        cards.add(new Card(11,'c'));
        cards.add(new Card(11,'h'));
        cards.add(new Card(11,'d'));

        cards.add(new Card(12,'s'));
        cards.add(new Card(12,'c'));
        cards.add(new Card(12,'h'));
        cards.add(new Card(12,'d'));

        cards.add(new Card(13,'s'));
        cards.add(new Card(13,'c'));
        cards.add(new Card(13,'h'));
        cards.add(new Card(13,'d'));

        cards.add(new Card(14,'s'));
        cards.add(new Card(14,'c'));
        cards.add(new Card(14,'h'));
        cards.add(new Card(14,'d'));
        Collections.shuffle(cards);
        Collections.shuffle(cards);
        for (Player temp: spieler){
            temp.hand.clear();
            temp.hand.add(cards.remove(0));
            temp.hand.add(cards.remove(0));
            temp.hand.add(cards.remove(0));
        }
    }

}