package com.company.schwimmen;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;

import java.util.ArrayList;
import java.util.Collections;

public class GamePRE extends Activity {
    ArrayList<Player> spieler = new ArrayList<>();
    int spieler_count = 2;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        spieler.clear();
        //Displayrientation setzen
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);

        //Title-Bar entfernen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //Content des Fensters laden (xml Datei)
        setContentView(R.layout.activity_game_pre);

        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);

        setListeners();
    }

    private void setListeners() {
        ImageButton button_game_menu = (ImageButton) findViewById(R.id.btnMainMenu);
        if (button_game_menu!=null)
            button_game_menu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    alertMessage();
                }
            });

        Button button_add = (Button) findViewById(R.id.btnAddPlayer);
        if (button_add != null)  button_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addPlayer();
            }
        });

        Button button_remove = (Button) findViewById(R.id.btnRemovePlayer);
        if (button_remove != null){button_remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                removePlayer();
            }
        });}

        Button button_go = (Button) findViewById(R.id.btnStartGame);
        if (button_go != null){button_go.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                newGame();
            }
        });
        }
        CheckBox boxShuffle = (CheckBox) findViewById(R.id.shuffleBox);
        if (boxShuffle!=null) {boxShuffle.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                mischen();
            }
        });
        }
        ImageButton btnPreHelp = (ImageButton) findViewById(R.id.btnPreHelp);
        if (btnPreHelp!=null)
            btnPreHelp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent in = new Intent(getApplicationContext(), GameSSHelp.class);
                    startActivity(in);
                }
            });

    }
    public void addPlayer(){
        Button button_add = (Button) findViewById(R.id.btnAddPlayer);
        Button button_remove = (Button) findViewById(R.id.btnRemovePlayer);
        EditText p3 = (EditText) findViewById(R.id.name3_text);
        EditText p4 = (EditText) findViewById(R.id.name4_text);
        EditText p5 = (EditText) findViewById(R.id.name5_text);
        EditText p6 = (EditText) findViewById(R.id.name6_text);
        EditText p7 = (EditText) findViewById(R.id.name7_text);
        EditText p8 = (EditText) findViewById(R.id.name8_text);
        EditText p9 = (EditText) findViewById(R.id.name9_text);
        CheckBox box3 = (CheckBox) findViewById(R.id.checkBox3);
        CheckBox box4 = (CheckBox) findViewById(R.id.checkBox4);
        CheckBox box5 = (CheckBox) findViewById(R.id.checkBox5);
        CheckBox box6 = (CheckBox) findViewById(R.id.checkBox6);
        CheckBox box7 = (CheckBox) findViewById(R.id.checkBox7);
        CheckBox box8 = (CheckBox) findViewById(R.id.checkBox8);
        CheckBox box9 = (CheckBox) findViewById(R.id.checkBox9);
        spieler_count++;
        if (spieler_count>9) spieler_count=9;
        else if (spieler_count<9&&button_add!=null) button_add.setVisibility(View.VISIBLE);

        switch (spieler_count){
            case 3:
                if (p3!=null) p3.setVisibility(View.VISIBLE);
                if (button_remove!=null) button_remove.setVisibility(View.VISIBLE);
                if (box3!=null) box3.setVisibility(View.VISIBLE);
                break;
            case 4:
                if (p4!=null) p4.setVisibility(View.VISIBLE);
                if (box4!=null) box4.setVisibility(View.VISIBLE);
                break;
            case 5:
                if (p5!=null) p5.setVisibility(View.VISIBLE);
                if (box5!=null) box5.setVisibility(View.VISIBLE);
                break;
            case 6:
                if (p6!=null) p6.setVisibility(View.VISIBLE);
                if (box6!=null) box6.setVisibility(View.VISIBLE);
                break;
            case 7:
                if (p7!=null) p7.setVisibility(View.VISIBLE);
                if (box7!=null) box7.setVisibility(View.VISIBLE);
                break;
            case 8:
                if (p8!=null) p8.setVisibility(View.VISIBLE);
                if (box8!=null) box8.setVisibility(View.VISIBLE);
                break;
            case 9:
                if (p9!=null) p9.setVisibility(View.VISIBLE);
                if (button_add!=null) button_add.setVisibility(View.INVISIBLE);
                if (box9!=null) box9.setVisibility(View.VISIBLE);
                break;
        }
    }
    public void removePlayer(){
        Button button_add = (Button) findViewById(R.id.btnAddPlayer);
        Button button_remove = (Button) findViewById(R.id.btnRemovePlayer);
        EditText p3 = (EditText) findViewById(R.id.name3_text);
        EditText p4 = (EditText) findViewById(R.id.name4_text);
        EditText p5 = (EditText) findViewById(R.id.name5_text);
        EditText p6 = (EditText) findViewById(R.id.name6_text);
        EditText p7 = (EditText) findViewById(R.id.name7_text);
        EditText p8 = (EditText) findViewById(R.id.name8_text);
        EditText p9 = (EditText) findViewById(R.id.name9_text);
        CheckBox box3 = (CheckBox) findViewById(R.id.checkBox3);
        CheckBox box4 = (CheckBox) findViewById(R.id.checkBox4);
        CheckBox box5 = (CheckBox) findViewById(R.id.checkBox5);
        CheckBox box6 = (CheckBox) findViewById(R.id.checkBox6);
        CheckBox box7 = (CheckBox) findViewById(R.id.checkBox7);
        CheckBox box8 = (CheckBox) findViewById(R.id.checkBox8);
        CheckBox box9 = (CheckBox) findViewById(R.id.checkBox9);

        spieler_count--;
        if (spieler_count<2)  spieler_count=2;
        switch (spieler_count){
            case 2:
                if (p3!=null) p3.setVisibility(View.GONE);
                if (box3!=null) box3.setVisibility(View.GONE);
                if (button_remove!=null) button_remove.setVisibility(View.INVISIBLE);
                break;
            case 3:
                if (p4!=null) p4.setVisibility(View.GONE);
                if (box4!=null) box4.setVisibility(View.GONE);
                break;
            case 4:
                if (p5!=null) p5.setVisibility(View.GONE);
                if (box5!=null) box5.setVisibility(View.GONE);
                break;
            case 5:
                if (p6!=null) p6.setVisibility(View.GONE);
                if (box6!=null) box6.setVisibility(View.GONE);
                break;
            case 6:
                if (p7!=null) p7.setVisibility(View.GONE);
                if (box7!=null) box7.setVisibility(View.GONE);
                break;
            case 7:
                if (p8!=null) p8.setVisibility(View.GONE);
                if (box8!=null) box8.setVisibility(View.GONE);
                break;
            case 8:
                if (p9!=null) p9.setVisibility(View.GONE);
                if (box9!=null) box9.setVisibility(View.GONE);
                if (button_add!=null) button_add.setVisibility(View.VISIBLE);
                break;
        }
    }
    public void setPlayerNames(){
        EditText p1 = (EditText) findViewById(R.id.name1_text);
        EditText p2 = (EditText) findViewById(R.id.name2_text);
        EditText p3 = (EditText) findViewById(R.id.name3_text);
        EditText p4 = (EditText) findViewById(R.id.name4_text);
        EditText p5 = (EditText) findViewById(R.id.name5_text);
        EditText p6 = (EditText) findViewById(R.id.name6_text);
        EditText p7 = (EditText) findViewById(R.id.name7_text);
        EditText p8 = (EditText) findViewById(R.id.name8_text);
        EditText p9 = (EditText) findViewById(R.id.name9_text);

        if (p1!=null&&p1.getText().toString().equals("")) p1.setText(R.string.hint_p1);
        if (p2!=null&&p2.getText().toString().equals("")) p2.setText(R.string.hint_p2);
        if (p3!=null&&p3.getText().toString().equals("")) p3.setText(R.string.hint_p3);
        if (p4!=null&&p4.getText().toString().equals("")) p4.setText(R.string.hint_p4);
        if (p5!=null&&p5.getText().toString().equals("")) p5.setText(R.string.hint_p5);
        if (p6!=null&&p6.getText().toString().equals("")) p6.setText(R.string.hint_p6);
        if (p7!=null&&p7.getText().toString().equals("")) p7.setText(R.string.hint_p7);
        if (p8!=null&&p8.getText().toString().equals("")) p8.setText(R.string.hint_p8);
        if (p9!=null&&p9.getText().toString().equals("")) p9.setText(R.string.hint_p9);
    }
    public void setPlayerList(){
        int leben = 3;
        EditText lebenInput = (EditText) findViewById(R.id.lebenInput) ;
        if (lebenInput != null) {
            if (lebenInput.getText()!=null) {
                String input = lebenInput.getText().toString();
                try { leben = Integer.parseInt(input);
                } catch(Exception e) {Log.e("GamePRE", "Exception: " + e.toString()+"\n"+e.getMessage());}
            }
        }
        EditText p1 = (EditText) findViewById(R.id.name1_text);
        EditText p2 = (EditText) findViewById(R.id.name2_text);
        EditText p3 = (EditText) findViewById(R.id.name3_text);
        EditText p4 = (EditText) findViewById(R.id.name4_text);
        EditText p5 = (EditText) findViewById(R.id.name5_text);
        EditText p6 = (EditText) findViewById(R.id.name6_text);
        EditText p7 = (EditText) findViewById(R.id.name7_text);
        EditText p8 = (EditText) findViewById(R.id.name8_text);
        EditText p9 = (EditText) findViewById(R.id.name9_text);
        spieler.clear();
        CheckBox box2 = (CheckBox) findViewById(R.id.checkBox2);
        CheckBox box3 = (CheckBox) findViewById(R.id.checkBox3);
        CheckBox box4 = (CheckBox) findViewById(R.id.checkBox4);
        CheckBox box5 = (CheckBox) findViewById(R.id.checkBox5);
        CheckBox box6 = (CheckBox) findViewById(R.id.checkBox6);
        CheckBox box7 = (CheckBox) findViewById(R.id.checkBox7);
        CheckBox box8 = (CheckBox) findViewById(R.id.checkBox8);
        CheckBox box9 = (CheckBox) findViewById(R.id.checkBox9);
        if (p1!=null) spieler.add(new Player(p1.getText().toString(),leben,false));
        if (p2!=null) spieler.add(new Player(p2.getText().toString(),leben, box2.isChecked()));

        switch (spieler_count){
            case 3:
                if (p3!=null) spieler.add(new Player(p3.getText().toString(),leben,box3.isChecked()));
                break;
            case 4:
                if (p3!=null) spieler.add(new Player(p3.getText().toString(),leben,box3.isChecked()));
                if (p4!=null) spieler.add(new Player(p4.getText().toString(),leben,box4.isChecked()));
                break;
            case 5:
                if (p3!=null) spieler.add(new Player(p3.getText().toString(),leben,box3.isChecked()));
                if (p4!=null) spieler.add(new Player(p4.getText().toString(),leben,box4.isChecked()));
                if (p5!=null) spieler.add(new Player(p5.getText().toString(),leben,box5.isChecked()));
                break;
            case 6:
                if (p3!=null) spieler.add(new Player(p3.getText().toString(),leben,box3.isChecked()));
                if (p4!=null) spieler.add(new Player(p4.getText().toString(),leben,box4.isChecked()));
                if (p5!=null) spieler.add(new Player(p5.getText().toString(),leben,box5.isChecked()));
                if (p6!=null) spieler.add(new Player(p6.getText().toString(),leben,box6.isChecked()));
                break;
            case 7:
                if (p3!=null) spieler.add(new Player(p3.getText().toString(),leben,box3.isChecked()));
                if (p4!=null) spieler.add(new Player(p4.getText().toString(),leben,box4.isChecked()));
                if (p5!=null) spieler.add(new Player(p5.getText().toString(),leben,box5.isChecked()));
                if (p6!=null) spieler.add(new Player(p6.getText().toString(),leben,box6.isChecked()));
                if (p7!=null) spieler.add(new Player(p7.getText().toString(),leben,box7.isChecked()));
                break;
            case 8:
                if (p3!=null) spieler.add(new Player(p3.getText().toString(),leben,box3.isChecked()));
                if (p4!=null) spieler.add(new Player(p4.getText().toString(),leben,box4.isChecked()));
                if (p5!=null) spieler.add(new Player(p5.getText().toString(),leben,box5.isChecked()));
                if (p6!=null) spieler.add(new Player(p6.getText().toString(),leben,box6.isChecked()));
                if (p7!=null) spieler.add(new Player(p7.getText().toString(),leben,box7.isChecked()));
                if (p8!=null) spieler.add(new Player(p8.getText().toString(),leben,box8.isChecked()));
                break;
            case 9:
                if (p3!=null) spieler.add(new Player(p3.getText().toString(),leben,box3.isChecked()));
                if (p4!=null) spieler.add(new Player(p4.getText().toString(),leben,box4.isChecked()));
                if (p5!=null) spieler.add(new Player(p5.getText().toString(),leben,box5.isChecked()));
                if (p6!=null) spieler.add(new Player(p6.getText().toString(),leben,box6.isChecked()));
                if (p7!=null) spieler.add(new Player(p7.getText().toString(),leben,box7.isChecked()));
                if (p8!=null) spieler.add(new Player(p8.getText().toString(),leben,box8.isChecked()));
                if (p9!=null) spieler.add(new Player(p9.getText().toString(),leben,box9.isChecked()));
                break;
        }
    }
    public void newGame(){
        setPlayerNames();
        setPlayerList();
        Intent in = new Intent(getApplicationContext(),GameSS.class);
        ThirtyOne.spieler=spieler;
        if (mischen()) Collections.shuffle(ThirtyOne.spieler);
        ThirtyOne.roundCount = 0;
        ThirtyOne.verlierer.clear();
        startActivity(in);
        finish();
    }
    public void alertMessage() {
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case DialogInterface.BUTTON_POSITIVE:
                        // Yes button clicked
                        Intent in = new Intent(getApplicationContext(), MainMenu.class);
                        startActivity(in);
                        finish();
                        break;
                    case DialogInterface.BUTTON_NEGATIVE:
                        break;
                    default: break;
                }
            }
        };
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.MainMenuDialog).setPositiveButton(R.string.Yes, dialogClickListener).setNegativeButton(R.string.No, dialogClickListener).show();
    }
    public boolean mischen(){
        CheckBox boxShuffle = (CheckBox) findViewById(R.id.shuffleBox);
        return boxShuffle.isChecked();
    }

}