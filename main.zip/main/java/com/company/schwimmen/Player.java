package com.company.schwimmen;

import android.util.Log;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Random;

class Player implements Comparator<Player> {
    String name;
    int leben;
    float handValue;
    boolean cpu;
    ArrayList<Card> hand = new ArrayList<>();
    ArrayList<Object> points = new ArrayList<>();

    Player(String playerName){
        this.name = playerName;
        this.leben = 0;
        this.handValue =0;
    }
    Player(String name, int leben, boolean checkBoxisChecked){
        this.name = name;
        this.leben = leben;
        this.handValue =0;
        this.cpu = checkBoxisChecked; //not checked: no cpu
    }
    void looseOneLife(){
        --this.leben;
        Log.i("EoR calls Player", this.name+": loosing one life, remaining: "+ this.leben + "♡");
        if (this.leben<0) {
            ThirtyOne.verlierer.add (ThirtyOne.spieler.remove(ThirtyOne.spieler.indexOf(this)));
            //FIXME addRoundCound (leftGame)
            Log.i("EoR calls Player", this.name+" is loosing the game and leaves");
        }
    }
    @Override
    public int compare(Player a, Player b){
        if (a.handValue < b.handValue) return 1; //absteigende Sortierung
        else return -1;
    }

    // Schwimmen KI
    private Card max(Card a, Card b){
        if (a!=null&&b!=null) {
            if (a.getValue() >= b.getValue()) return a;
            return b;
        }
        return new Card(99,'a');
    }
    private Card min(Card a, Card b){
        if (a!=null&&b!=null) {
            if (a.getValue() > b.getValue()) return b;
            return a;
        }
        return new Card(99,'a');
    }

    //returns true if Player has any pair (equal cardrank) in his hand
    boolean tripsPossible() {
        return this.hand.get(0).rank == this.hand.get(1).rank || this.hand.get(1).rank == this.hand.get(2).rank || this.hand.get(2).rank == this.hand.get(0).rank;
    }
    //todo color up with pair in hand
    //returns true if there is a suit match with the Board (Player.hand → board)
    int boardImprovementIndex(){
        //TODO pair up and get color points
        char symbol = this.getTargetSymbol();
        Card board0 = ThirtyOne.board.hand.get(0);
        Card board1 = ThirtyOne.board.hand.get(1);
        Card board2 = ThirtyOne.board.hand.get(2);
        if (board0.suit.equals(symbol)) //higher rank?
            if(board0.getValue() > ThirtyOne.active.hand.get(this.worstCardIndex()).getValue()) return 0;
        if (board1.suit.equals(symbol)) //higher rank?
            if(board1.getValue() > ThirtyOne.active.hand.get(this.worstCardIndex()).getValue()) return 1;
        if (board0.suit.equals(symbol)) //higher rank?
            if(board2.getValue() > ThirtyOne.active.hand.get(this.worstCardIndex()).getValue()) return 2;
        return 100;
    }
    boolean threeSameSuits() {
        return (this.hand.get(0).suit == this.hand.get(1).suit) && (this.hand.get(2).suit == this.hand.get(1).suit);
    }
    //returns the suit which improves Player.hand, or random char
    char getTargetSymbol(){
        if (this.hand.size()>1) {
            boolean a = this.hand.get(0).suit == this.hand.get(1).suit;
            boolean a1= this.hand.get(0).suit != this.hand.get(1).suit;
            boolean b = this.hand.get(1).suit == this.hand.get(2).suit;
            boolean b1= this.hand.get(1).suit != this.hand.get(2).suit;
            boolean c = this.hand.get(0).suit == this.hand.get(2).suit;
            //three equal symbols on hand
            if (a && b) return this.hand.get(0).suit;
            //two equal
            if (a && b1) return this.hand.get(0).suit;
            if (a1 && b) return this.hand.get(1).suit;
            else if (c)  return this.hand.get(2).suit;
            //three different symbols, if trips not possible: get highest Card suit
            return maxCardChar();
        }
        //return randomSymbol();
        return 'a';
    }
    //returns the index [0,2] of worst Player.hand (player will discard this Card)
    int worstCardIndex(){
        char ziel = this.getTargetSymbol();
        if (ziel!='a'){
            boolean a = this.hand.get(0).suit ==ziel;
            boolean a0= this.hand.get(0).suit !=ziel;
            boolean b = this.hand.get(1).suit ==ziel;
            boolean b0= this.hand.get(1).suit !=ziel;
            boolean c = this.hand.get(2).suit ==ziel;
            boolean c0= this.hand.get(2).suit !=ziel;
            //two equal symbols: swap wrong suit
            if (a&&b&&c0) return 2;
            if (a&&b0&&c) return 1;
            if (a0&&b&&c) return 0;
            //no equal symbols or three equal symbols: swap lowest with highest suit match
            return minCardIndex();
        }
        //FIXME swap lowest color to board
        return 100;
    }




    private int randomInt(int hi, int lo){
        Random r = new Random();
        return r.nextInt(hi-lo) + lo;
    }
    private char randomSymbol(){
        int rand = randomInt(0,3);
        if (rand == 0) return 's';
        if (rand == 1) return 'd';
        if (rand == 2) return 'h';
        return 'c';
    }
    private int minCardIndex(){
        Card card0 = null;
        Card card1 = null;
        Card card2 = null;
        if (this.hand.get(0)!=null) card0 = this.hand.get(0);
        if (this.hand.get(1)!=null) card1 = this.hand.get(1);
        if (this.hand.get(2)!=null) card2 = this.hand.get(2);
        if (card0!=null&&card1!=null&&card2!=null){
            Card min = min(min(card0, card1), card2);
            if (min==card0) return 0;
            if (min==card1) return 1;
            if (min==card2) return 2;
        }
        return randomInt(0,2);
    }
    private int maxCardIndex(){
        Card card0  = null;
        Card card1 = null;
        Card card2 = null;
        if (this.hand.get(0)!=null) card0 = this.hand.get(0);
        if (this.hand.get(1)!=null) card1 = this.hand.get(1);
        if (this.hand.get(2)!=null) card2 = this.hand.get(2);
        if (card0!=null&&card1!=null&&card2!=null){
            Card max = max(max(card0, card1),card2);
            if (max==card0) return 0;
            if (max==card1) return 1;
            if (max==card2) return 2;
        }
        return randomInt(0,2);
    }
    private Card HiLoCard(boolean hi){
        Card card0 = null;
        Card card1 = null;
        Card card2 = null;
        if (this.hand.get(0)!=null) card0 = this.hand.get(0);
        if (this.hand.get(1)!=null) card1 = this.hand.get(1);
        if (this.hand.get(2)!=null) card2 = this.hand.get(2);
        if ((card0!=null&&card1!=null&&card2!=null)){
            if (hi) return max(card2, max(card0, card1));
            else return min(card2, min(card0,card1));
        }
        return new Card(99,'a');
    }
    private char maxCardChar(){return HiLoCard(true).suit;}
    private char minCardChar(){return HiLoCard(false).suit;}

    //classic hand evaluation
    private int maxCardValue(){
        if (this.hand.size()>1){
            if (this.hand.get(0).getValue() >= this.hand.get(1).getValue()) {
                if (this.hand.get(0).getValue() >= this.hand.get(2).getValue()) {
                    return this.hand.get(0).getValue();
                }
            }
            if (this.hand.get(1).getValue() >= this.hand.get(2).getValue()) {
                return this.hand.get(1).getValue();
            }
            return this.hand.get(2).getValue();
        }
        return 0;
    }
    private int handValueByColor(){
        if (this.hand.size()>1) {
            boolean a = this.hand.get(0).suit == this.hand.get(1).suit;
            boolean a1= this.hand.get(0).suit != this.hand.get(1).suit;
            boolean b = this.hand.get(1).suit == this.hand.get(2).suit;
            boolean b1= this.hand.get(1).suit != this.hand.get(2).suit;
            boolean c = this.hand.get(0).suit == this.hand.get(2).suit;
            if (a && b) {
                    int value = this.hand.get(0).getValue() + this.hand.get(1).getValue() + this.hand.get(2).getValue();
                    if (value == 31) value = 50;
                    return value;
            }
            if (a && b1)  return this.hand.get(0).getValue() + this.hand.get(1).getValue();
            if (a1 && b)  return this.hand.get(1).getValue() + this.hand.get(2).getValue();
            else if (c)   return this.hand.get(0).getValue() + this.hand.get(2).getValue();
        }
        return this.maxCardValue();
    }
    private float handValueTrips(){
        if (this.hand.size()>1){
        if ( (this.hand.get(0).rank == this.hand.get(1).rank) && (this.hand.get(2).rank ==this.hand.get(0).rank) ) {
            return 30.5f + this.hand.get(0).rank; //37.5: A,A,A
        }}
        return 0;
    }
    private float max(int a, float b){
        if (a>=b) return a;
        return b;
    }
    private int round(float value){return Math.round(value);}
    float evaluateHand(){
        this.handValue = this.max(this.handValueByColor(), this.handValueTrips());
        return this.handValue;
    }
    Object adjustedHandValue(){
        float value = this.evaluateHand();
        if (value==50f) return 31;
        else if (value>=30.5f) return value - this.hand.get(0).rank;
        return round(value);
    }
}
